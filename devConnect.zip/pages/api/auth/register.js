import { hashPassword } from '@lib/bcrypt';
import connect from 'next-connect';

import dbConnect from '@utils/startup/db';
import User from '@utils/models/user';

export default connect().post(async (req, res) => {
  await dbConnect();
  // const result = Validate(req.body, res);
  // if (result === undefined) return;

  let user = await User.findOne({ username: req.body.username });
  if (user)
    return res.status(400).json({ username: 'Username is already registered' });

  const password = await hashPassword(req.body.password);
  user = new User({ username: req.body.username, password, new: false });

  await user.save();
  return res.status(201).json('created');
});
