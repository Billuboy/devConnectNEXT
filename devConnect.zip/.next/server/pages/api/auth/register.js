"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/auth/register";
exports.ids = ["pages/api/auth/register"];
exports.modules = {

/***/ "./lib/bcrypt.js":
/*!***********************!*\
  !*** ./lib/bcrypt.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"hashPassword\": () => (/* binding */ hashPassword),\n/* harmony export */   \"comparePassword\": () => (/* binding */ comparePassword)\n/* harmony export */ });\n/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bcryptjs */ \"bcryptjs\");\n/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_0__);\n\nasync function hashPassword(password) {\n  const salt = await bcryptjs__WEBPACK_IMPORTED_MODULE_0___default().genSalt(10);\n  const hash = await bcryptjs__WEBPACK_IMPORTED_MODULE_0___default().hash(password, salt);\n  return hash;\n}\nasync function comparePassword(password, hash) {\n  const check = await bcryptjs__WEBPACK_IMPORTED_MODULE_0___default().compare(password, hash);\n  return check;\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9saWIvYmNyeXB0LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTtBQUVPLGVBQWVDLFlBQWYsQ0FBNEJDLFFBQTVCLEVBQXNDO0FBQzNDLFFBQU1DLElBQUksR0FBRyxNQUFNSCx1REFBQSxDQUFlLEVBQWYsQ0FBbkI7QUFDQSxRQUFNSyxJQUFJLEdBQUcsTUFBTUwsb0RBQUEsQ0FBWUUsUUFBWixFQUFzQkMsSUFBdEIsQ0FBbkI7QUFDQSxTQUFPRSxJQUFQO0FBQ0Q7QUFFTSxlQUFlQyxlQUFmLENBQStCSixRQUEvQixFQUF5Q0csSUFBekMsRUFBK0M7QUFDcEQsUUFBTUUsS0FBSyxHQUFHLE1BQU1QLHVEQUFBLENBQWVFLFFBQWYsRUFBeUJHLElBQXpCLENBQXBCO0FBQ0EsU0FBT0UsS0FBUDtBQUNEIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xpZW50Ly4vbGliL2JjcnlwdC5qcz8zOTY5Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBiY3J5cHQgZnJvbSAnYmNyeXB0anMnO1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaGFzaFBhc3N3b3JkKHBhc3N3b3JkKSB7XG4gIGNvbnN0IHNhbHQgPSBhd2FpdCBiY3J5cHQuZ2VuU2FsdCgxMCk7XG4gIGNvbnN0IGhhc2ggPSBhd2FpdCBiY3J5cHQuaGFzaChwYXNzd29yZCwgc2FsdCk7XG4gIHJldHVybiBoYXNoO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY29tcGFyZVBhc3N3b3JkKHBhc3N3b3JkLCBoYXNoKSB7XG4gIGNvbnN0IGNoZWNrID0gYXdhaXQgYmNyeXB0LmNvbXBhcmUocGFzc3dvcmQsIGhhc2gpO1xuICByZXR1cm4gY2hlY2s7XG59XG4iXSwibmFtZXMiOlsiYmNyeXB0IiwiaGFzaFBhc3N3b3JkIiwicGFzc3dvcmQiLCJzYWx0IiwiZ2VuU2FsdCIsImhhc2giLCJjb21wYXJlUGFzc3dvcmQiLCJjaGVjayIsImNvbXBhcmUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./lib/bcrypt.js\n");

/***/ }),

/***/ "./pages/api/auth/register.js":
/*!************************************!*\
  !*** ./pages/api/auth/register.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _lib_bcrypt__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lib/bcrypt */ \"./lib/bcrypt.js\");\n/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-connect */ \"next-connect\");\n/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_connect__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _utils_startup_db__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @utils/startup/db */ \"./utils/startup/db.js\");\n/* harmony import */ var _utils_models_user__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @utils/models/user */ \"./utils/models/user.js\");\n\n\n\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_connect__WEBPACK_IMPORTED_MODULE_1___default()().post(async (req, res) => {\n  await (0,_utils_startup_db__WEBPACK_IMPORTED_MODULE_2__.default)(); // const result = Validate(req.body, res);\n  // if (result === undefined) return;\n\n  let user = await _utils_models_user__WEBPACK_IMPORTED_MODULE_3__.default.findOne({\n    username: req.body.username\n  });\n  if (user) return res.status(400).json({\n    username: 'Username is already registered'\n  });\n  const password = await (0,_lib_bcrypt__WEBPACK_IMPORTED_MODULE_0__.hashPassword)(req.body.password);\n  user = new _utils_models_user__WEBPACK_IMPORTED_MODULE_3__.default({\n    username: req.body.username,\n    password,\n    new: false\n  });\n  await user.save();\n  return res.status(201).json('created');\n}));//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9hcGkvYXV0aC9yZWdpc3Rlci5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQTtBQUNBO0FBRUE7QUFDQTtBQUVBLGlFQUFlQyxtREFBTyxHQUFHRyxJQUFWLENBQWUsT0FBT0MsR0FBUCxFQUFZQyxHQUFaLEtBQW9CO0FBQ2hELFFBQU1KLDBEQUFTLEVBQWYsQ0FEZ0QsQ0FFaEQ7QUFDQTs7QUFFQSxNQUFJSyxJQUFJLEdBQUcsTUFBTUosK0RBQUEsQ0FBYTtBQUFFTSxJQUFBQSxRQUFRLEVBQUVKLEdBQUcsQ0FBQ0ssSUFBSixDQUFTRDtBQUFyQixHQUFiLENBQWpCO0FBQ0EsTUFBSUYsSUFBSixFQUNFLE9BQU9ELEdBQUcsQ0FBQ0ssTUFBSixDQUFXLEdBQVgsRUFBZ0JDLElBQWhCLENBQXFCO0FBQUVILElBQUFBLFFBQVEsRUFBRTtBQUFaLEdBQXJCLENBQVA7QUFFRixRQUFNSSxRQUFRLEdBQUcsTUFBTWIseURBQVksQ0FBQ0ssR0FBRyxDQUFDSyxJQUFKLENBQVNHLFFBQVYsQ0FBbkM7QUFDQU4sRUFBQUEsSUFBSSxHQUFHLElBQUlKLHVEQUFKLENBQVM7QUFBRU0sSUFBQUEsUUFBUSxFQUFFSixHQUFHLENBQUNLLElBQUosQ0FBU0QsUUFBckI7QUFBK0JJLElBQUFBLFFBQS9CO0FBQXlDQyxJQUFBQSxHQUFHLEVBQUU7QUFBOUMsR0FBVCxDQUFQO0FBRUEsUUFBTVAsSUFBSSxDQUFDUSxJQUFMLEVBQU47QUFDQSxTQUFPVCxHQUFHLENBQUNLLE1BQUosQ0FBVyxHQUFYLEVBQWdCQyxJQUFoQixDQUFxQixTQUFyQixDQUFQO0FBQ0QsQ0FkYyxDQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xpZW50Ly4vcGFnZXMvYXBpL2F1dGgvcmVnaXN0ZXIuanM/OTUyOSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBoYXNoUGFzc3dvcmQgfSBmcm9tICdAbGliL2JjcnlwdCc7XG5pbXBvcnQgY29ubmVjdCBmcm9tICduZXh0LWNvbm5lY3QnO1xuXG5pbXBvcnQgZGJDb25uZWN0IGZyb20gJ0B1dGlscy9zdGFydHVwL2RiJztcbmltcG9ydCBVc2VyIGZyb20gJ0B1dGlscy9tb2RlbHMvdXNlcic7XG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QoKS5wb3N0KGFzeW5jIChyZXEsIHJlcykgPT4ge1xuICBhd2FpdCBkYkNvbm5lY3QoKTtcbiAgLy8gY29uc3QgcmVzdWx0ID0gVmFsaWRhdGUocmVxLmJvZHksIHJlcyk7XG4gIC8vIGlmIChyZXN1bHQgPT09IHVuZGVmaW5lZCkgcmV0dXJuO1xuXG4gIGxldCB1c2VyID0gYXdhaXQgVXNlci5maW5kT25lKHsgdXNlcm5hbWU6IHJlcS5ib2R5LnVzZXJuYW1lIH0pO1xuICBpZiAodXNlcilcbiAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDApLmpzb24oeyB1c2VybmFtZTogJ1VzZXJuYW1lIGlzIGFscmVhZHkgcmVnaXN0ZXJlZCcgfSk7XG5cbiAgY29uc3QgcGFzc3dvcmQgPSBhd2FpdCBoYXNoUGFzc3dvcmQocmVxLmJvZHkucGFzc3dvcmQpO1xuICB1c2VyID0gbmV3IFVzZXIoeyB1c2VybmFtZTogcmVxLmJvZHkudXNlcm5hbWUsIHBhc3N3b3JkLCBuZXc6IGZhbHNlIH0pO1xuXG4gIGF3YWl0IHVzZXIuc2F2ZSgpO1xuICByZXR1cm4gcmVzLnN0YXR1cygyMDEpLmpzb24oJ2NyZWF0ZWQnKTtcbn0pO1xuIl0sIm5hbWVzIjpbImhhc2hQYXNzd29yZCIsImNvbm5lY3QiLCJkYkNvbm5lY3QiLCJVc2VyIiwicG9zdCIsInJlcSIsInJlcyIsInVzZXIiLCJmaW5kT25lIiwidXNlcm5hbWUiLCJib2R5Iiwic3RhdHVzIiwianNvbiIsInBhc3N3b3JkIiwibmV3Iiwic2F2ZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/api/auth/register.js\n");

/***/ }),

/***/ "./utils/models/user.js":
/*!******************************!*\
  !*** ./utils/models/user.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst Schema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({\n  username: {\n    type: String,\n    required: true\n  },\n  avatar: {\n    type: String\n  },\n  displayName: {\n    type: String\n  },\n  password: {\n    type: String\n  },\n  email: {\n    type: String\n  },\n  date: {\n    type: Date,\n    default: Date.now\n  },\n  new: {\n    type: Boolean,\n    default: true\n  }\n});\nconst User = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.users) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model('users', Schema);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (User);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi91dGlscy9tb2RlbHMvdXNlci5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQTtBQUVBLE1BQU1DLE1BQU0sR0FBRyxJQUFJRCx3REFBSixDQUFvQjtBQUNqQ0UsRUFBQUEsUUFBUSxFQUFFO0FBQ1JDLElBQUFBLElBQUksRUFBRUMsTUFERTtBQUVSQyxJQUFBQSxRQUFRLEVBQUU7QUFGRixHQUR1QjtBQUtqQ0MsRUFBQUEsTUFBTSxFQUFFO0FBQ05ILElBQUFBLElBQUksRUFBRUM7QUFEQSxHQUx5QjtBQVFqQ0csRUFBQUEsV0FBVyxFQUFFO0FBQ1hKLElBQUFBLElBQUksRUFBRUM7QUFESyxHQVJvQjtBQVdqQ0ksRUFBQUEsUUFBUSxFQUFFO0FBQ1JMLElBQUFBLElBQUksRUFBRUM7QUFERSxHQVh1QjtBQWNqQ0ssRUFBQUEsS0FBSyxFQUFFO0FBQ0xOLElBQUFBLElBQUksRUFBRUM7QUFERCxHQWQwQjtBQWlCakNNLEVBQUFBLElBQUksRUFBRTtBQUNKUCxJQUFBQSxJQUFJLEVBQUVRLElBREY7QUFFSkMsSUFBQUEsT0FBTyxFQUFFRCxJQUFJLENBQUNFO0FBRlYsR0FqQjJCO0FBcUJqQ0MsRUFBQUEsR0FBRyxFQUFFO0FBQ0hYLElBQUFBLElBQUksRUFBRVksT0FESDtBQUVISCxJQUFBQSxPQUFPLEVBQUU7QUFGTjtBQXJCNEIsQ0FBcEIsQ0FBZjtBQTJCQSxNQUFNSSxJQUFJLEdBQUdoQiw4REFBQSxJQUF5QkEscURBQUEsQ0FBZSxPQUFmLEVBQXdCQyxNQUF4QixDQUF0QztBQUNBLGlFQUFlZSxJQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xpZW50Ly4vdXRpbHMvbW9kZWxzL3VzZXIuanM/NjllNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbW9uZ29vc2UgZnJvbSAnbW9uZ29vc2UnO1xuXG5jb25zdCBTY2hlbWEgPSBuZXcgbW9uZ29vc2UuU2NoZW1hKHtcbiAgdXNlcm5hbWU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gICAgcmVxdWlyZWQ6IHRydWUsXG4gIH0sXG4gIGF2YXRhcjoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgfSxcbiAgZGlzcGxheU5hbWU6IHtcbiAgICB0eXBlOiBTdHJpbmcsXG4gIH0sXG4gIHBhc3N3b3JkOiB7XG4gICAgdHlwZTogU3RyaW5nLFxuICB9LFxuICBlbWFpbDoge1xuICAgIHR5cGU6IFN0cmluZyxcbiAgfSxcbiAgZGF0ZToge1xuICAgIHR5cGU6IERhdGUsXG4gICAgZGVmYXVsdDogRGF0ZS5ub3csXG4gIH0sXG4gIG5ldzoge1xuICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgZGVmYXVsdDogdHJ1ZSxcbiAgfSxcbn0pO1xuXG5jb25zdCBVc2VyID0gbW9uZ29vc2UubW9kZWxzLnVzZXJzIHx8IG1vbmdvb3NlLm1vZGVsKCd1c2VycycsIFNjaGVtYSk7XG5leHBvcnQgZGVmYXVsdCBVc2VyO1xuIl0sIm5hbWVzIjpbIm1vbmdvb3NlIiwiU2NoZW1hIiwidXNlcm5hbWUiLCJ0eXBlIiwiU3RyaW5nIiwicmVxdWlyZWQiLCJhdmF0YXIiLCJkaXNwbGF5TmFtZSIsInBhc3N3b3JkIiwiZW1haWwiLCJkYXRlIiwiRGF0ZSIsImRlZmF1bHQiLCJub3ciLCJuZXciLCJCb29sZWFuIiwiVXNlciIsIm1vZGVscyIsInVzZXJzIiwibW9kZWwiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./utils/models/user.js\n");

/***/ }),

/***/ "./utils/startup/db.js":
/*!*****************************!*\
  !*** ./utils/startup/db.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst {\n  MONGODB_URI,\n  SECRET_KEY\n} = process.env;\n\nif (!MONGODB_URI && !SECRET_KEY) {\n  throw new Error('Please define the MONGODB_URI and SECRET_KEY environment variable inside .env.local');\n}\n\nlet cached = global.mongoose;\n\nif (!cached) {\n  cached = global.mongoose = {\n    conn: null,\n    promise: null\n  };\n}\n\nasync function dbConnect() {\n  if (cached.conn) {\n    return cached.conn;\n  }\n\n  if (!cached.promise) {\n    const opts = {\n      useNewUrlParser: true,\n      useUnifiedTopology: true,\n      useFindAndModify: false,\n      useCreateIndex: true\n    };\n    cached.promise = mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(MONGODB_URI, opts).then(mongoose => {\n      console.log('MongoDB Connected');\n      return mongoose;\n    });\n  }\n\n  cached.conn = await cached.promise;\n  return cached.conn;\n}\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dbConnect);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi91dGlscy9zdGFydHVwL2RiLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBRUEsTUFBTTtBQUFFQyxFQUFBQSxXQUFGO0FBQWVDLEVBQUFBO0FBQWYsSUFBOEJDLE9BQU8sQ0FBQ0MsR0FBNUM7O0FBRUEsSUFBSSxDQUFDSCxXQUFELElBQWdCLENBQUNDLFVBQXJCLEVBQWlDO0FBQy9CLFFBQU0sSUFBSUcsS0FBSixDQUNKLHFGQURJLENBQU47QUFHRDs7QUFFRCxJQUFJQyxNQUFNLEdBQUdDLE1BQU0sQ0FBQ1AsUUFBcEI7O0FBRUEsSUFBSSxDQUFDTSxNQUFMLEVBQWE7QUFDWEEsRUFBQUEsTUFBTSxHQUFHQyxNQUFNLENBQUNQLFFBQVAsR0FBa0I7QUFBRVEsSUFBQUEsSUFBSSxFQUFFLElBQVI7QUFBY0MsSUFBQUEsT0FBTyxFQUFFO0FBQXZCLEdBQTNCO0FBQ0Q7O0FBRUQsZUFBZUMsU0FBZixHQUEyQjtBQUN6QixNQUFJSixNQUFNLENBQUNFLElBQVgsRUFBaUI7QUFDZixXQUFPRixNQUFNLENBQUNFLElBQWQ7QUFDRDs7QUFFRCxNQUFJLENBQUNGLE1BQU0sQ0FBQ0csT0FBWixFQUFxQjtBQUNuQixVQUFNRSxJQUFJLEdBQUc7QUFDWEMsTUFBQUEsZUFBZSxFQUFFLElBRE47QUFFWEMsTUFBQUEsa0JBQWtCLEVBQUUsSUFGVDtBQUdYQyxNQUFBQSxnQkFBZ0IsRUFBRSxLQUhQO0FBSVhDLE1BQUFBLGNBQWMsRUFBRTtBQUpMLEtBQWI7QUFPQVQsSUFBQUEsTUFBTSxDQUFDRyxPQUFQLEdBQWlCVCx1REFBQSxDQUFpQkMsV0FBakIsRUFBOEJVLElBQTlCLEVBQW9DTSxJQUFwQyxDQUF5Q2pCLFFBQVEsSUFBSTtBQUNwRWtCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLG1CQUFaO0FBQ0EsYUFBT25CLFFBQVA7QUFDRCxLQUhnQixDQUFqQjtBQUlEOztBQUNETSxFQUFBQSxNQUFNLENBQUNFLElBQVAsR0FBYyxNQUFNRixNQUFNLENBQUNHLE9BQTNCO0FBQ0EsU0FBT0gsTUFBTSxDQUFDRSxJQUFkO0FBQ0Q7O0FBRUQsaUVBQWVFLFNBQWYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGllbnQvLi91dGlscy9zdGFydHVwL2RiLmpzPzQ1YmIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG1vbmdvb3NlIGZyb20gJ21vbmdvb3NlJztcblxuY29uc3QgeyBNT05HT0RCX1VSSSwgU0VDUkVUX0tFWSB9ID0gcHJvY2Vzcy5lbnY7XG5cbmlmICghTU9OR09EQl9VUkkgJiYgIVNFQ1JFVF9LRVkpIHtcbiAgdGhyb3cgbmV3IEVycm9yKFxuICAgICdQbGVhc2UgZGVmaW5lIHRoZSBNT05HT0RCX1VSSSBhbmQgU0VDUkVUX0tFWSBlbnZpcm9ubWVudCB2YXJpYWJsZSBpbnNpZGUgLmVudi5sb2NhbCdcbiAgKTtcbn1cblxubGV0IGNhY2hlZCA9IGdsb2JhbC5tb25nb29zZTtcblxuaWYgKCFjYWNoZWQpIHtcbiAgY2FjaGVkID0gZ2xvYmFsLm1vbmdvb3NlID0geyBjb25uOiBudWxsLCBwcm9taXNlOiBudWxsIH07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGRiQ29ubmVjdCgpIHtcbiAgaWYgKGNhY2hlZC5jb25uKSB7XG4gICAgcmV0dXJuIGNhY2hlZC5jb25uO1xuICB9XG5cbiAgaWYgKCFjYWNoZWQucHJvbWlzZSkge1xuICAgIGNvbnN0IG9wdHMgPSB7XG4gICAgICB1c2VOZXdVcmxQYXJzZXI6IHRydWUsXG4gICAgICB1c2VVbmlmaWVkVG9wb2xvZ3k6IHRydWUsXG4gICAgICB1c2VGaW5kQW5kTW9kaWZ5OiBmYWxzZSxcbiAgICAgIHVzZUNyZWF0ZUluZGV4OiB0cnVlLFxuICAgIH07XG5cbiAgICBjYWNoZWQucHJvbWlzZSA9IG1vbmdvb3NlLmNvbm5lY3QoTU9OR09EQl9VUkksIG9wdHMpLnRoZW4obW9uZ29vc2UgPT4ge1xuICAgICAgY29uc29sZS5sb2coJ01vbmdvREIgQ29ubmVjdGVkJyk7XG4gICAgICByZXR1cm4gbW9uZ29vc2U7XG4gICAgfSk7XG4gIH1cbiAgY2FjaGVkLmNvbm4gPSBhd2FpdCBjYWNoZWQucHJvbWlzZTtcbiAgcmV0dXJuIGNhY2hlZC5jb25uO1xufVxuXG5leHBvcnQgZGVmYXVsdCBkYkNvbm5lY3Q7XG4iXSwibmFtZXMiOlsibW9uZ29vc2UiLCJNT05HT0RCX1VSSSIsIlNFQ1JFVF9LRVkiLCJwcm9jZXNzIiwiZW52IiwiRXJyb3IiLCJjYWNoZWQiLCJnbG9iYWwiLCJjb25uIiwicHJvbWlzZSIsImRiQ29ubmVjdCIsIm9wdHMiLCJ1c2VOZXdVcmxQYXJzZXIiLCJ1c2VVbmlmaWVkVG9wb2xvZ3kiLCJ1c2VGaW5kQW5kTW9kaWZ5IiwidXNlQ3JlYXRlSW5kZXgiLCJjb25uZWN0IiwidGhlbiIsImNvbnNvbGUiLCJsb2ciXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./utils/startup/db.js\n");

/***/ }),

/***/ "bcryptjs":
/*!***************************!*\
  !*** external "bcryptjs" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ "next-connect":
/*!*******************************!*\
  !*** external "next-connect" ***!
  \*******************************/
/***/ ((module) => {

module.exports = require("next-connect");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/api/auth/register.js"));
module.exports = __webpack_exports__;

})();