"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/404";
exports.ids = ["pages/404"];
exports.modules = {

/***/ "./pages/404.jsx":
/*!***********************!*\
  !*** ./pages/404.jsx ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ NotFound)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__);\nvar _jsxFileName = \"/work/Projects/devConnect/pages/404.jsx\";\n// import React from 'react';\n// import Head from 'next/head';\n// import { Box, Grid, Text } from '@chakra-ui/react';\n// export default function NotFound() {\n//   return (\n//     <>\n//       <Head>\n//         <title>404</title>\n//         <meta name=\"viewport\" content=\"initial-scale=1.0, width=device-width\" />\n//       </Head>\n//       <Box h=\"calc(100vh - 130px)\">\n//         <Grid h=\"100%\" placeItems=\"center\">\n//           <Box>\n//             <Text\n//               color=\"#fff\"\n//               textAlign=\"center\"\n//               fontSize=\"2.5rem\"\n//               fontWeight=\"700\">\n//               404\n//             </Text>\n//             <Text color=\"#fff\" fontSize=\"1.75rem\" fontWeight=\"600\">\n//               Page Not Found\n//             </Text>\n//           </Box>\n//         </Grid>\n//       </Box>\n//     </>\n//   );\n// }\n\n\nfunction NotFound() {\n  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(\"div\", {\n    children: \"NotFound\"\n  }, void 0, false, {\n    fileName: _jsxFileName,\n    lineNumber: 36,\n    columnNumber: 10\n  }, this);\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy80MDQuanN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTs7QUFFZSxTQUFTQyxRQUFULEdBQW9CO0FBQ2pDLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQVA7QUFDRCIsInNvdXJjZXMiOlsid2VicGFjazovL2NsaWVudC8uL3BhZ2VzLzQwNC5qc3g/ZjJhOCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuLy8gaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJztcbi8vIGltcG9ydCB7IEJveCwgR3JpZCwgVGV4dCB9IGZyb20gJ0BjaGFrcmEtdWkvcmVhY3QnO1xuXG4vLyBleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBOb3RGb3VuZCgpIHtcbi8vICAgcmV0dXJuIChcbi8vICAgICA8PlxuLy8gICAgICAgPEhlYWQ+XG4vLyAgICAgICAgIDx0aXRsZT40MDQ8L3RpdGxlPlxuLy8gICAgICAgICA8bWV0YSBuYW1lPVwidmlld3BvcnRcIiBjb250ZW50PVwiaW5pdGlhbC1zY2FsZT0xLjAsIHdpZHRoPWRldmljZS13aWR0aFwiIC8+XG4vLyAgICAgICA8L0hlYWQ+XG5cbi8vICAgICAgIDxCb3ggaD1cImNhbGMoMTAwdmggLSAxMzBweClcIj5cbi8vICAgICAgICAgPEdyaWQgaD1cIjEwMCVcIiBwbGFjZUl0ZW1zPVwiY2VudGVyXCI+XG4vLyAgICAgICAgICAgPEJveD5cbi8vICAgICAgICAgICAgIDxUZXh0XG4vLyAgICAgICAgICAgICAgIGNvbG9yPVwiI2ZmZlwiXG4vLyAgICAgICAgICAgICAgIHRleHRBbGlnbj1cImNlbnRlclwiXG4vLyAgICAgICAgICAgICAgIGZvbnRTaXplPVwiMi41cmVtXCJcbi8vICAgICAgICAgICAgICAgZm9udFdlaWdodD1cIjcwMFwiPlxuLy8gICAgICAgICAgICAgICA0MDRcbi8vICAgICAgICAgICAgIDwvVGV4dD5cbi8vICAgICAgICAgICAgIDxUZXh0IGNvbG9yPVwiI2ZmZlwiIGZvbnRTaXplPVwiMS43NXJlbVwiIGZvbnRXZWlnaHQ9XCI2MDBcIj5cbi8vICAgICAgICAgICAgICAgUGFnZSBOb3QgRm91bmRcbi8vICAgICAgICAgICAgIDwvVGV4dD5cbi8vICAgICAgICAgICA8L0JveD5cbi8vICAgICAgICAgPC9HcmlkPlxuLy8gICAgICAgPC9Cb3g+XG4vLyAgICAgPC8+XG4vLyAgICk7XG4vLyB9XG5cbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE5vdEZvdW5kKCkge1xuICByZXR1cm4gPGRpdj5Ob3RGb3VuZDwvZGl2Pjtcbn1cbiJdLCJuYW1lcyI6WyJSZWFjdCIsIk5vdEZvdW5kIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/404.jsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/404.jsx"));
module.exports = __webpack_exports__;

})();